const exchange = require("../../js/promotions/exchange/exchange");
const exchangeRateProvider = require("../../js/promotions/exchange/exchangeRateProvider");