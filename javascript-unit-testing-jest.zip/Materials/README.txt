Node modules have not been included to reduce the size of the folder.
Node modules can be installed using npm install.